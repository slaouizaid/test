"use client"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { Mail, Github, Linkedin, Download, Phone, MapPin, Calendar } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function Portfolio() {
  const [openProject, setOpenProject] = useState<string | null>(null)

  const projects = [
    {
      id: "java-project",
      title: "Java-Anwendung zur Projektverwaltung",
      description:
        "Entwicklung einer Java-Anwendung zur Verwaltung von Projekt- und Mitarbeiterdaten mit automatisierter Berichterstellung.",
      tags: ["Java", "Datenvisualisierung", "Berichterstellung"],
      fullDescription:
        "Diese Anwendung wurde während meines Praktikums bei STANDARD PROFIL entwickelt. Sie ermöglicht die effiziente Verwaltung von Projektdaten und Mitarbeiterinformationen. Die Hauptfunktionen umfassen die Erfassung von Projektmeilensteinen, die Zuweisung von Ressourcen und die automatische Generierung von Fortschrittsberichten. Durch die Integration von Datenvisualisierungstools können Projektmanager den Status ihrer Projekte in Echtzeit überwachen und fundierte Entscheidungen treffen.",
      technologies: [
        "Java SE",
        "JavaFX für die Benutzeroberfläche",
        "JPA für die Datenbankanbindung",
        "JFreeChart für die Datenvisualisierung",
        "Apache POI für die Berichterstellung",
      ],
      challenges:
        "Eine besondere Herausforderung war die Implementierung eines effizienten Algorithmus zur Ressourcenoptimierung, der die Verfügbarkeit von Mitarbeitern mit den Projektanforderungen abgleicht.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "ecommerce",
      title: "E-Commerce Web-Anwendung",
      description:
        "Design und Entwicklung einer E-Commerce-Plattform mit Benutzerauthentifizierung und Produktverwaltung.",
      tags: ["HTML/CSS", "JavaScript", "PHP", "MySQL"],
      fullDescription:
        "Im Rahmen meines Praktikums bei STARTUP MEDIA entwickelte ich eine vollständige E-Commerce-Lösung für einen lokalen Händler. Die Plattform bietet eine intuitive Benutzeroberfläche für Kunden und ein umfassendes Backend-System für die Verwaltung von Produkten, Bestellungen und Kundendaten.",
      technologies: [
        "HTML5/CSS3 für das Frontend",
        "JavaScript für interaktive Elemente",
        "PHP für serverseitige Logik",
        "MySQL für die Datenspeicherung",
        "Responsive Design für mobile Geräte",
      ],
      challenges:
        "Die größte Herausforderung bestand darin, ein sicheres Zahlungssystem zu implementieren und gleichzeitig eine optimale Benutzererfahrung zu gewährleisten.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "it-automation",
      title: "IT-Support-Automatisierung",
      description:
        "Entwicklung von Skripten zur Automatisierung wiederkehrender IT-Support-Aufgaben und Systemwartung.",
      tags: ["Python", "Bash", "Automatisierung"],
      fullDescription:
        "Als Werkstudent im IT-Support bei Flick Gocke Schaumburg entwickelte ich eine Reihe von Automatisierungsskripten, die wiederkehrende Aufgaben wie Systemupdates, Backups und Benutzerkontoerstellung automatisieren. Dies führte zu einer erheblichen Zeitersparnis und Reduzierung manueller Fehler.",
      technologies: [
        "Python für komplexe Automatisierungsaufgaben",
        "Bash-Skripte für Linux-basierte Systeme",
        "PowerShell für Windows-Umgebungen",
        "Cron-Jobs für geplante Ausführungen",
      ],
      challenges:
        "Die Herausforderung bestand darin, plattformübergreifende Lösungen zu entwickeln, die sowohl in Windows- als auch in Linux-Umgebungen funktionieren.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "medical-data",
      title: "Medizinische Datenanalyse-Tool",
      description: "Entwicklung eines Tools zur Analyse und Visualisierung medizinischer Daten für Forschungszwecke.",
      tags: ["Python", "Data Analysis", "Visualisierung", "Medizintechnik"],
      fullDescription:
        "Während meines Studiums der Medizintechnik an der Hochschule Remagen entwickelte ich ein spezialisiertes Tool zur Analyse medizinischer Daten. Die Anwendung ermöglicht Forschern, große Datensätze zu importieren, zu bereinigen und mittels verschiedener statistischer Methoden zu analysieren. Die Ergebnisse werden in interaktiven Visualisierungen dargestellt, die tiefere Einblicke in medizinische Trends und Muster ermöglichen.",
      technologies: [
        "Python mit Pandas für Datenmanipulation",
        "NumPy für numerische Berechnungen",
        "Matplotlib und Seaborn für Visualisierungen",
        "Scikit-learn für statistische Analysen",
        "Jupyter Notebooks für interaktive Dokumentation",
      ],
      challenges:
        "Die größte Herausforderung war die Entwicklung eines benutzerfreundlichen Interfaces, das auch von Medizinern ohne tiefgreifende IT-Kenntnisse genutzt werden kann.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "smart-home",
      title: "Smart Home Steuerungssystem",
      description: "Entwicklung eines Systems zur zentralen Steuerung von Smart Home Geräten verschiedener Hersteller.",
      tags: ["C#", "IoT", "API Integration", "WPF"],
      fullDescription:
        "Als persönliches Projekt entwickelte ich ein zentrales Steuerungssystem für Smart Home Geräte. Die Anwendung integriert verschiedene Hersteller-APIs und ermöglicht die einheitliche Steuerung von Beleuchtung, Heizung, Sicherheitssystemen und anderen IoT-Geräten über eine einzige Benutzeroberfläche. Das System unterstützt auch automatisierte Abläufe und zeitgesteuerte Aktionen.",
      technologies: [
        "C# und .NET Framework als Basis",
        "WPF für die Desktop-Benutzeroberfläche",
        "REST API Integrationen für verschiedene Gerätehersteller",
        "MQTT für die Kommunikation mit IoT-Geräten",
        "SQLite für lokale Datenspeicherung",
      ],
      challenges:
        "Die größte Herausforderung war die Integration der verschiedenen Hersteller-APIs, die unterschiedliche Authentifizierungsmethoden und Datenformate verwenden.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "language-learning",
      title: "Sprachlern-App mit KI-Unterstützung",
      description:
        "Entwicklung einer mobilen App zum Sprachenlernen mit KI-gestützter Aussprachekorrektur und personalisierten Lernplänen.",
      tags: ["React Native", "Python", "TensorFlow", "Mobile Development"],
      fullDescription:
        "Basierend auf meinen eigenen Erfahrungen beim Deutschlernen entwickelte ich eine mobile Anwendung, die Sprachlernenden hilft, ihre Aussprache zu verbessern und personalisierte Lernpläne zu erstellen. Die App nutzt KI-Algorithmen, um die Aussprache zu analysieren und Feedback in Echtzeit zu geben. Zudem passt sich der Lernplan automatisch an die Fortschritte und Schwierigkeiten des Nutzers an.",
      technologies: [
        "React Native für plattformübergreifende mobile Entwicklung",
        "Python mit Flask für das Backend",
        "TensorFlow für die Spracherkennung und -analyse",
        "MongoDB für die Datenspeicherung",
        "WebRTC für Audioaufnahmen",
      ],
      challenges:
        "Die Integration der Spracherkennungstechnologie in eine mobile Anwendung mit begrenzten Ressourcen war besonders herausfordernd.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "hospital-management",
      title: "Krankenhaus-Managementsystem",
      description:
        "Entwicklung eines umfassenden Managementsystems für Krankenhäuser zur Verwaltung von Patienten, Personal und Ressourcen.",
      tags: ["Java", "Spring Boot", "PostgreSQL", "Medizintechnik"],
      fullDescription:
        "Dieses Projekt kombiniert meine Kenntnisse in Informatik und Medizintechnik. Ich entwickelte ein modulares Krankenhaus-Managementsystem, das verschiedene Aspekte des Krankenhausbetriebs abdeckt: Patientenverwaltung, Terminplanung, Personalverwaltung, Medikamentenbestand und Ressourcenzuweisung. Das System bietet eine rollenbasierte Zugriffssteuerung für verschiedene Benutzergruppen wie Ärzte, Pflegepersonal und Verwaltungsmitarbeiter.",
      technologies: [
        "Java mit Spring Boot für das Backend",
        "Thymeleaf für serverseitiges Rendering",
        "PostgreSQL für die Datenspeicherung",
        "Spring Security für Authentifizierung und Autorisierung",
        "JUnit und Mockito für Tests",
        "Docker für die Containerisierung",
      ],
      challenges:
        "Die größte Herausforderung war die Entwicklung eines Systems, das sowohl den strengen Datenschutzanforderungen im Gesundheitswesen entspricht als auch eine intuitive Benutzeroberfläche für medizinisches Personal bietet.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "biometric-auth",
      title: "Biometrisches Authentifizierungssystem",
      description:
        "Implementierung eines mehrschichtigen Authentifizierungssystems mit Gesichtserkennung und Fingerabdruckscanner.",
      tags: ["Python", "OpenCV", "Biometrie", "Sicherheit"],
      fullDescription:
        "Dieses Projekt entstand aus meinem Interesse an IT-Sicherheit und Biometrie. Ich entwickelte ein mehrschichtiges Authentifizierungssystem, das Gesichtserkennung und Fingerabdruckscans kombiniert, um einen hohen Sicherheitsstandard zu gewährleisten. Das System verwendet Algorithmen des maschinellen Lernens, um Gesichter zu erkennen und zu verifizieren, und integriert sich mit handelsüblichen Fingerabdruckscannern.",
      technologies: [
        "Python als Hauptprogrammiersprache",
        "OpenCV für die Bildverarbeitung und Gesichtserkennung",
        "TensorFlow für das Training der Gesichtserkennungsmodelle",
        "PyQt für die Benutzeroberfläche",
        "SQLite für die lokale Datenspeicherung",
        "Raspberry Pi für die Hardware-Integration",
      ],
      challenges:
        "Die Hauptherausforderung bestand darin, ein System zu entwickeln, das sowohl sicher als auch benutzerfreundlich ist, mit minimalen Falsch-Positiv- und Falsch-Negativ-Raten bei der biometrischen Erkennung.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "virtual-classroom",
      title: "Virtuelle Klassenzimmer-Plattform",
      description:
        "Entwicklung einer interaktiven Plattform für Online-Unterricht mit Echtzeit-Kollaboration und Fortschrittsverfolgung.",
      tags: ["React", "Node.js", "WebRTC", "MongoDB"],
      fullDescription:
        "Inspiriert von meinen Erfahrungen im Fernunterricht entwickelte ich eine virtuelle Klassenzimmer-Plattform, die Echtzeit-Videokonferenzen, interaktive Whiteboards und Dokumentenfreigabe kombiniert. Die Plattform bietet Lehrern Tools zur Erstellung von Kursinhalten, zur Durchführung von Prüfungen und zur Verfolgung des Fortschritts der Schüler. Für Schüler bietet sie personalisierte Lernpfade und Kollaborationsmöglichkeiten.",
      technologies: [
        "React für das Frontend",
        "Node.js und Express für das Backend",
        "WebRTC für Echtzeit-Videokommunikation",
        "Socket.io für Echtzeit-Datenübertragung",
        "MongoDB für die Datenspeicherung",
        "AWS S3 für die Speicherung von Kursmaterialien",
      ],
      challenges:
        "Die größte Herausforderung war die Implementierung einer stabilen Echtzeit-Kommunikation mit niedriger Latenz, die auch bei schlechter Internetverbindung zuverlässig funktioniert.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "fitness-tracker",
      title: "Fitness-Tracking-App mit Gesundheitsanalyse",
      description:
        "Entwicklung einer mobilen App zur Verfolgung von Fitness-Aktivitäten und Gesundheitsmetriken mit personalisierten Empfehlungen.",
      tags: ["Flutter", "Firebase", "Machine Learning", "Health Tech"],
      fullDescription:
        "Dieses Projekt verbindet mein Interesse an Fitness (Gym als Hobby) mit meinen technischen Fähigkeiten. Ich entwickelte eine umfassende Fitness-Tracking-App, die verschiedene Trainingsarten verfolgt, Ernährungspläne erstellt und Gesundheitsmetriken analysiert. Die App verwendet Algorithmen des maschinellen Lernens, um personalisierte Trainings- und Ernährungsempfehlungen basierend auf den Zielen und dem Fortschritt des Benutzers zu geben.",
      technologies: [
        "Flutter für die plattformübergreifende App-Entwicklung",
        "Firebase für Backend-Dienste und Authentifizierung",
        "TensorFlow Lite für On-Device Machine Learning",
        "HealthKit (iOS) und Google Fit (Android) Integration",
        "Cloud Functions für serverseitige Logik",
      ],
      challenges:
        "Die Hauptherausforderung bestand darin, genaue und personalisierte Empfehlungen zu generieren, die sowohl effektiv als auch sicher für verschiedene Benutzerprofile sind, von Anfängern bis zu fortgeschrittenen Sportlern.",
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "sap-integration",
      title: "SAP-Integrationsplattform für Unternehmensprozesse",
      description:
        "Entwicklung einer Integrationsplattform zur Verbindung von SAP ERP mit externen Systemen und Optimierung von Geschäftsprozessen.",
      tags: ["SAP ERP", "ABAP", "SAP HANA", "API Integration", "Prozessautomatisierung"],
      category: "enterprise",
      fullDescription:
        "Als Teil eines Unternehmensprojekts entwickelte ich eine Integrationsplattform, die SAP ERP mit verschiedenen externen Systemen verbindet. Die Lösung automatisiert den Datenaustausch zwischen SAP und anderen Unternehmensanwendungen, optimiert Geschäftsprozesse und reduziert manuelle Eingriffe. Durch die Integration von Echtzeit-Datenanalysen mit SAP HANA konnten Entscheidungsprozesse beschleunigt und die Effizienz gesteigert werden.",
      technologies: [
        "SAP ERP als zentrales System",
        "ABAP für kundenspezifische Entwicklungen",
        "SAP HANA für Echtzeit-Datenanalyse",
        "SAP Fiori für moderne Benutzeroberflächen",
        "REST APIs für die Integration externer Systeme",
        "SAP Process Integration für Workflow-Automatisierung",
      ],
      challenges:
        "Die größte Herausforderung bestand in der nahtlosen Integration verschiedener Systeme mit unterschiedlichen Datenformaten und Protokollen, während gleichzeitig die Sicherheit und Integrität der Unternehmensdaten gewährleistet werden musste.",
      image: "/placeholder.svg?height=300&width=500",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="mr-4 hidden md:flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="font-bold">Zaid Slaoui</span>
            </Link>
            <nav className="flex items-center space-x-6 text-sm font-medium">
              <Link href="#about" className="transition-colors hover:text-foreground/80">
                Über mich
              </Link>
              <Link href="#education" className="transition-colors hover:text-foreground/80">
                Ausbildung
              </Link>
              <Link href="#experience" className="transition-colors hover:text-foreground/80">
                Erfahrung
              </Link>
              <Link href="#skills" className="transition-colors hover:text-foreground/80">
                Fähigkeiten
              </Link>
              <Link href="#projects" className="transition-colors hover:text-foreground/80">
                Projekte
              </Link>
              <Link href="#contact" className="transition-colors hover:text-foreground/80">
                Kontakt
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
            <Button variant="outline" size="sm" className="ml-auto">
              <Download className="mr-2 h-4 w-4" />
              Lebenslauf
            </Button>
          </div>
        </div>
      </header>
      <main className="container py-6 md:py-12">
        <section id="about" className="mb-12 md:mb-24">
          <div className="grid gap-6 md:grid-cols-2 md:gap-12">
            <div className="flex flex-col justify-center space-y-4">
              <div>
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Zaid Slaoui</h1>
                <p className="text-xl text-muted-foreground">Informatikstudent & Entwickler</p>
              </div>
              <div className="space-y-2 text-muted-foreground">
                <div className="flex items-center">
                  <MapPin className="mr-2 h-4 w-4" />
                  <p>Pariser Straße 54, 53117 Bonn</p>
                </div>
                <div className="flex items-center">
                  <Phone className="mr-2 h-4 w-4" />
                  <p>+49 159 06778061</p>
                </div>
                <div className="flex items-center">
                  <Mail className="mr-2 h-4 w-4" />
                  <p>zaidslaoui@outlook.de</p>
                </div>
                <div className="flex items-center">
                  <Calendar className="mr-2 h-4 w-4" />
                  <p>02.01.1996, Marokko</p>
                </div>
              </div>
              <p className="text-muted-foreground">
                Ich bin ein engagierter Informatikstudent mit Erfahrung in der Softwareentwicklung und IT-Support. Meine
                Leidenschaft liegt in der Entwicklung innovativer Lösungen und der Anwendung meiner vielseitigen
                technischen Fähigkeiten zur Lösung komplexer Probleme.
              </p>
              <div className="flex gap-4">
                <Button asChild size="sm">
                  <Link href="#contact">Kontakt aufnehmen</Link>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <Link href="#projects">Projekte ansehen</Link>
                </Button>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="relative h-64 w-64 overflow-hidden rounded-full border-4 border-background shadow-xl">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Bildschirmfoto%202024-02-08%20um%2013.14.21.jpg-246EWNgnPKE31r0ZmG4MuooP51z0Jk.png"
                  alt="Zaid Slaoui"
                  fill
                  style={{ objectFit: "cover" }}
                  priority
                />
              </div>
            </div>
          </div>
        </section>

        <section id="education" className="mb-12 md:mb-24">
          <h2 className="mb-6 text-2xl font-bold tracking-tighter sm:text-3xl">Ausbildung</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Bachelor of Science in Informatik</h3>
                    <p className="text-sm text-muted-foreground">Hochschule Bonn Rhein-Sieg</p>
                  </div>
                  <p className="text-sm text-muted-foreground">09/2023 - Heute</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Aktuelles Studium im Bereich Informatik</li>
                  <li>• Schwerpunkt auf Softwareentwicklung und Programmierung</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Medizintechnik</h3>
                    <p className="text-sm text-muted-foreground">Hochschule Remagen</p>
                  </div>
                  <p className="text-sm text-muted-foreground">09/2021 - 07/2023</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Studium im Bereich Medizintechnik</li>
                  <li>• Interdisziplinäre Ausbildung zwischen Technik und Medizin</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Deutsch-Kurs</h3>
                    <p className="text-sm text-muted-foreground">Universität Paderborn</p>
                  </div>
                  <p className="text-sm text-muted-foreground">04/2019 - 04/2020</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Intensiver Deutschkurs zur Vorbereitung auf das Studium in Deutschland</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Bachelor in Informatik</h3>
                    <p className="text-sm text-muted-foreground">
                      Fakultät für Wissenschaft und Technik (FSTT), Tangier
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground">09/2014 - 06/2018</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Abschluss in Technischer Informatik</li>
                  <li>• Grundlegende und fortgeschrittene Informatikkonzepte</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">SAP Professional Grundlagen</h3>
                    <p className="text-sm text-muted-foreground">SAP SE</p>
                  </div>
                  <p className="text-sm text-muted-foreground">15.01.2025</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Zertifizierung in SAP-Grundlagen und Kernmodulen</li>
                  <li>• Umfassendes Verständnis der SAP ERP-Architektur</li>
                  <li>• Kenntnisse in SAP ABAP, SAP HANA und SAP Fiori</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        <section id="experience" className="mb-12 md:mb-24">
          <h2 className="mb-6 text-2xl font-bold tracking-tighter sm:text-3xl">Berufserfahrung</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Werkstudent IT Support</h3>
                    <p className="text-sm text-muted-foreground">Flick Gocke Schaumburg, Bonn</p>
                  </div>
                  <p className="text-sm text-muted-foreground">04/2025 - Heute</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Unterstützung im täglichen IT-Support für Mitarbeitende</li>
                  <li>• Fehleranalyse und Bearbeitung von IT-Störungen (First- und ggf. Second-Level)</li>
                  <li>• Pflege von Hard- und Software-Systemen</li>
                  <li>• Mitarbeit an IT-Projekten und Optimierungsmaßnahmen</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Wissenschaftliche Hilfskraft</h3>
                    <p className="text-sm text-muted-foreground">Universitätsklinikum Bonn</p>
                  </div>
                  <p className="text-sm text-muted-foreground">11/2024 - 03/2025</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Unterstützung bei der Verwaltung studien- und prüfungsrechtlicher Vorgänge</li>
                  <li>• Pflege digitaler Studierendendaten und Betreuung des iPad-Pools</li>
                  <li>• Mitarbeit bei Schulungen und allgemeine Bürotätigkeiten</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Praktikum</h3>
                    <p className="text-sm text-muted-foreground">STANDARD PROFIL, Tangier/Marokko</p>
                  </div>
                  <p className="text-sm text-muted-foreground">09/2018 - 06/2018</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Entwicklung einer Java-Anwendung zur Verwaltung von Projekt- und Mitarbeiterdaten</li>
                  <li>• Analyse von Produktionsprozessen und Visualisierung des Projektstatus mittels Diagramme</li>
                  <li>• Automatisierte Berichterstellung zur Überwachung von Projektfortschritten</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold">Praktikum</h3>
                    <p className="text-sm text-muted-foreground">STARTUP MEDIA, Tangier/Marokko</p>
                  </div>
                  <p className="text-sm text-muted-foreground">09/2018 - 31/2018</p>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <li>• Entwicklung eines Web/E-Commerce-Anwendung</li>
                  <li>• Design und Entwicklung der Anwendung</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        <section id="skills" className="mb-12 md:mb-24">
          <h2 className="mb-6 text-2xl font-bold tracking-tighter sm:text-3xl">Fähigkeiten</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <h3 className="mb-4 font-bold">Programmiersprachen</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Java</span>
                    <span className="text-sm text-muted-foreground">90%</span>
                  </div>
                  <Progress value={90} className="h-2 w-full" />
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">C#</span>
                    <span className="text-sm text-muted-foreground">85%</span>
                  </div>
                  <Progress value={85} className="h-2 w-full" />
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Python</span>
                    <span className="text-sm text-muted-foreground">80%</span>
                  </div>
                  <Progress value={80} className="h-2 w-full" />
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">JavaScript/HTML/CSS</span>
                    <span className="text-sm text-muted-foreground">85%</span>
                  </div>
                  <Progress value={85} className="h-2 w-full" />
                </div>
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">PHP</span>
                    <span className="text-sm text-muted-foreground">75%</span>
                  </div>
                  <Progress value={75} className="h-2 w-full" />
                </div>
              </div>
            </div>
            <div>
              <h3 className="mb-4 font-bold">Frameworks & Tools</h3>
              <div className="flex flex-wrap gap-2">
                <Badge>WPF</Badge>
                <Badge>.NET</Badge>
                <Badge>Flask</Badge>
                <Badge>Vaadin</Badge>
                <Badge>Spring Boot</Badge>
                <Badge>OpenCV</Badge>
                <Badge>JPA</Badge>
                <Badge>MySQL</Badge>
                <Badge>Oracle</Badge>
                <Badge>PostgreSQL</Badge>
                <Badge>JUnit</Badge>
                <Badge>NUnit</Badge>
                <Badge>Canva</Badge>
                <Badge>Figma</Badge>
                <Badge>Draw.io</Badge>
                <Badge>PlantUML</Badge>
                <Badge>Jira</Badge>
                <Badge>Jenkins</Badge>
                <Badge>SonarQube</Badge>
                <Badge>Nginx</Badge>
                <Badge>SAP ERP</Badge>
                <Badge>SAP ABAP</Badge>
                <Badge>SAP HANA</Badge>
                <Badge>SAP Fiori</Badge>
              </div>

              <h3 className="mb-4 mt-6 font-bold">Technische Fähigkeiten</h3>
              <div className="flex flex-wrap gap-2">
                <Badge>Windows</Badge>
                <Badge>macOS</Badge>
                <Badge>Linux</Badge>
                <Badge>Microsoft Office</Badge>
                <Badge>Agile/SCRUM</Badge>
                <Badge>UML-Diagramm</Badge>
              </div>

              <h3 className="mb-4 mt-6 font-bold">Sprachen</h3>
              <div className="flex flex-wrap gap-2">
                <Badge>Deutsch (Fließend)</Badge>
                <Badge>Englisch (Fließend)</Badge>
                <Badge>Französisch (Fließend)</Badge>
                <Badge>Arabisch (Muttersprache)</Badge>
              </div>
            </div>
          </div>
        </section>

        <section id="projects" className="mb-12 md:mb-24">
          <h2 className="mb-6 text-2xl font-bold tracking-tighter sm:text-3xl">Projekte</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <Card
                key={project.id}
                className="group relative overflow-hidden transition-all duration-300 hover:shadow-lg"
                onMouseEnter={() => setOpenProject(project.id)}
                onMouseLeave={() => setOpenProject(null)}
              >
                <CardContent className="p-6">
                  <h3 className="font-bold">{project.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{project.description}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <Badge key={tag} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <div
                    className={`absolute inset-0 flex flex-col justify-center bg-background/95 p-6 opacity-0 backdrop-blur transition-opacity duration-300 ${
                      openProject === project.id ? "opacity-100" : ""
                    }`}
                  >
                    <h3 className="mb-2 font-bold">{project.title}</h3>
                    <p className="mb-4 text-sm">{project.fullDescription}</p>
                    <div className="mb-4">
                      <h4 className="mb-1 text-sm font-semibold">Technologien:</h4>
                      <ul className="list-inside list-disc text-sm text-muted-foreground">
                        {project.technologies.map((tech, index) => (
                          <li key={index}>{tech}</li>
                        ))}
                      </ul>
                    </div>
                    <p className="text-sm">
                      <span className="font-semibold">Herausforderung:</span> {project.challenges}
                    </p>
                    <Button className="mt-4 self-start" size="sm">
                      Mehr Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section id="contact" className="mb-12 md:mb-24">
          <h2 className="mb-6 text-2xl font-bold tracking-tighter sm:text-3xl">Kontakt</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardContent className="p-6">
                <h3 className="mb-4 font-bold">Kontaktinformationen</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-muted-foreground" />
                    <span>zaidslaoui@outlook.de</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-muted-foreground" />
                    <span>+49 159 06778061</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <span>Pariser Straße 54, 53117 Bonn</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Linkedin className="h-5 w-5 text-muted-foreground" />
                    <Link href="#" className="hover:underline">
                      LinkedIn Profil
                    </Link>
                  </div>
                  <div className="flex items-center gap-2">
                    <Github className="h-5 w-5 text-muted-foreground" />
                    <Link href="#" className="hover:underline">
                      GitHub Profil
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <h3 className="mb-4 font-bold">Nachricht senden</h3>
                <form className="space-y-4">
                  <div className="grid gap-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Name
                    </label>
                    <input
                      id="name"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Dein Name"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      E-Mail
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="deine.email@beispiel.de"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Nachricht
                    </label>
                    <textarea
                      id="message"
                      className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Deine Nachricht..."
                    />
                  </div>
                  <Button type="submit">Senden</Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>

        <section id="hobbies" className="mb-12 md:mb-24">
          <h2 className="mb-6 text-2xl font-bold tracking-tighter sm:text-3xl">Hobbys & Interessen</h2>
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-wrap gap-4">
                <Badge className="px-3 py-1 text-base">Gym</Badge>
                <Badge className="px-3 py-1 text-base">Reisen</Badge>
                <Badge className="px-3 py-1 text-base">Fußball</Badge>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Zaid Slaoui. Alle Rechte vorbehalten.
          </p>
        </div>
      </footer>
    </div>
  )
}
