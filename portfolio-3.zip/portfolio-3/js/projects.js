// Projektdaten
const projects = [
  {
    id: "java-project",
    title: "Java-Anwendung zur Projektverwaltung",
    description:
      "Entwicklung einer Java-Anwendung zur Verwaltung von Projekt- und Mitarbeiterdaten mit automatisierter Berichterstellung.",
    tags: ["Java", "Datenvisualisierung", "Berichterstellung"],
    category: "desktop",
    fullDescription:
      "Diese Anwendung wurde während meines Praktikums bei STANDARD PROFIL entwickelt. Sie ermöglicht die effiziente Verwaltung von Projektdaten und Mitarbeiterinformationen. Die Hauptfunktionen umfassen die Erfassung von Projektmeilensteinen, die Zuweisung von Ressourcen und die automatische Generierung von Fortschrittsberichten. Durch die Integration von Datenvisualisierungstools können Projektmanager den Status ihrer Projekte in Echtzeit überwachen und fundierte Entscheidungen treffen.",
    technologies: [
      "Java SE",
      "JavaFX für die Benutzeroberfläche",
      "JPA für die Datenbankanbindung",
      "JFreeChart für die Datenvisualisierung",
      "Apache POI für die Berichterstellung",
    ],
    challenges:
      "Eine besondere Herausforderung war die Implementierung eines effizienten Algorithmus zur Ressourcenoptimierung, der die Verfügbarkeit von Mitarbeitern mit den Projektanforderungen abgleicht.",
    image: "images/placeholder.jpg",
  },
  {
    id: "ecommerce",
    title: "E-Commerce Web-Anwendung",
    description:
      "Design und Entwicklung einer E-Commerce-Plattform mit Benutzerauthentifizierung und Produktverwaltung.",
    tags: ["HTML/CSS", "JavaScript", "PHP", "MySQL"],
    category: "web",
    fullDescription:
      "Im Rahmen meines Praktikums bei STARTUP MEDIA entwickelte ich eine vollständige E-Commerce-Lösung für einen lokalen Händler. Die Plattform bietet eine intuitive Benutzeroberfläche für Kunden und ein umfassendes Backend-System für die Verwaltung von Produkten, Bestellungen und Kundendaten.",
    technologies: [
      "HTML5/CSS3 für das Frontend",
      "JavaScript für interaktive Elemente",
      "PHP für serverseitige Logik",
      "MySQL für die Datenspeicherung",
      "Responsive Design für mobile Geräte",
    ],
    challenges:
      "Die größte Herausforderung bestand darin, ein sicheres Zahlungssystem zu implementieren und gleichzeitig eine optimale Benutzererfahrung zu gewährleisten.",
    image: "images/placeholder.jpg",
  },
  {
    id: "it-automation",
    title: "IT-Support-Automatisierung",
    description: "Entwicklung von Skripten zur Automatisierung wiederkehrender IT-Support-Aufgaben und Systemwartung.",
    tags: ["Python", "Bash", "Automatisierung"],
    category: "desktop",
    fullDescription:
      "Als Werkstudent im IT-Support bei Flick Gocke Schaumburg entwickelte ich eine Reihe von Automatisierungsskripten, die wiederkehrende Aufgaben wie Systemupdates, Backups und Benutzerkontoerstellung automatisieren. Dies führte zu einer erheblichen Zeitersparnis und Reduzierung manueller Fehler.",
    technologies: [
      "Python für komplexe Automatisierungsaufgaben",
      "Bash-Skripte für Linux-basierte Systeme",
      "PowerShell für Windows-Umgebungen",
      "Cron-Jobs für geplante Ausführungen",
    ],
    challenges:
      "Die Herausforderung bestand darin, plattformübergreifende Lösungen zu entwickeln, die sowohl in Windows- als auch in Linux-Umgebungen funktionieren.",
    image: "images/placeholder.jpg",
  },
  {
    id: "medical-data",
    title: "Medizinische Datenanalyse-Tool",
    description: "Entwicklung eines Tools zur Analyse und Visualisierung medizinischer Daten für Forschungszwecke.",
    tags: ["Python", "Data Analysis", "Visualisierung", "Medizintechnik"],
    category: "desktop",
    fullDescription:
      "Während meines Studiums der Medizintechnik an der Hochschule Remagen entwickelte ich ein spezialisiertes Tool zur Analyse medizinischer Daten. Die Anwendung ermöglicht Forschern, große Datensätze zu importieren, zu bereinigen und mittels verschiedener statistischer Methoden zu analysieren. Die Ergebnisse werden in interaktiven Visualisierungen dargestellt, die tiefere Einblicke in medizinische Trends und Muster ermöglichen.",
    technologies: [
      "Python mit Pandas für Datenmanipulation",
      "NumPy für numerische Berechnungen",
      "Matplotlib und Seaborn für Visualisierungen",
      "Scikit-learn für statistische Analysen",
      "Jupyter Notebooks für interaktive Dokumentation",
    ],
    challenges:
      "Die größte Herausforderung war die Entwicklung eines benutzerfreundlichen Interfaces, das auch von Medizinern ohne tiefgreifende IT-Kenntnisse genutzt werden kann.",
    image: "images/placeholder.jpg",
  },
  {
    id: "smart-home",
    title: "Smart Home Steuerungssystem",
    description: "Entwicklung eines Systems zur zentralen Steuerung von Smart Home Geräten verschiedener Hersteller.",
    tags: ["C#", "IoT", "API Integration", "WPF"],
    category: "desktop",
    fullDescription:
      "Als persönliches Projekt entwickelte ich ein zentrales Steuerungssystem für Smart Home Geräte. Die Anwendung integriert verschiedene Hersteller-APIs und ermöglicht die einheitliche Steuerung von Beleuchtung, Heizung, Sicherheitssystemen und anderen IoT-Geräten über eine einzige Benutzeroberfläche. Das System unterstützt auch automatisierte Abläufe und zeitgesteuerte Aktionen.",
    technologies: [
      "C# und .NET Framework als Basis",
      "WPF für die Desktop-Benutzeroberfläche",
      "REST API Integrationen für verschiedene Gerätehersteller",
      "MQTT für die Kommunikation mit IoT-Geräten",
      "SQLite für lokale Datenspeicherung",
    ],
    challenges:
      "Die größte Herausforderung war die Integration der verschiedenen Hersteller-APIs, die unterschiedliche Authentifizierungsmethoden und Datenformate verwenden.",
    image: "images/placeholder.jpg",
  },
  {
    id: "language-learning",
    title: "Sprachlern-App mit KI-Unterstützung",
    description:
      "Entwicklung einer mobilen App zum Sprachenlernen mit KI-gestützter Aussprachekorrektur und personalisierten Lernplänen.",
    tags: ["React Native", "Python", "TensorFlow", "Mobile Development"],
    category: "mobile",
    fullDescription:
      "Basierend auf meinen eigenen Erfahrungen beim Deutschlernen entwickelte ich eine mobile Anwendung, die Sprachlernenden hilft, ihre Aussprache zu verbessern und personalisierte Lernpläne zu erstellen. Die App nutzt KI-Algorithmen, um die Aussprache zu analysieren und Feedback in Echtzeit zu geben. Zudem passt sich der Lernplan automatisch an die Fortschritte und Schwierigkeiten des Nutzers an.",
    technologies: [
      "React Native für plattformübergreifende mobile Entwicklung",
      "Python mit Flask für das Backend",
      "TensorFlow für die Spracherkennung und -analyse",
      "MongoDB für die Datenspeicherung",
      "WebRTC für Audioaufnahmen",
    ],
    challenges:
      "Die Integration der Spracherkennungstechnologie in eine mobile Anwendung mit begrenzten Ressourcen war besonders herausfordernd.",
    image: "images/placeholder.jpg",
  },
  {
    id: "hospital-management",
    title: "Krankenhaus-Managementsystem",
    description:
      "Entwicklung eines umfassenden Managementsystems für Krankenhäuser zur Verwaltung von Patienten, Personal und Ressourcen.",
    tags: ["Java", "Spring Boot", "PostgreSQL", "Medizintechnik"],
    category: "web",
    fullDescription:
      "Dieses Projekt kombiniert meine Kenntnisse in Informatik und Medizintechnik. Ich entwickelte ein modulares Krankenhaus-Managementsystem, das verschiedene Aspekte des Krankenhausbetriebs abdeckt: Patientenverwaltung, Terminplanung, Personalverwaltung, Medikamentenbestand und Ressourcenzuweisung. Das System bietet eine rollenbasierte Zugriffssteuerung für verschiedene Benutzergruppen wie Ärzte, Pflegepersonal und Verwaltungsmitarbeiter.",
    technologies: [
      "Java mit Spring Boot für das Backend",
      "Thymeleaf für serverseitiges Rendering",
      "PostgreSQL für die Datenspeicherung",
      "Spring Security für Authentifizierung und Autorisierung",
      "JUnit und Mockito für Tests",
      "Docker für die Containerisierung",
    ],
    challenges:
      "Die größte Herausforderung war die Entwicklung eines Systems, das sowohl den strengen Datenschutzanforderungen im Gesundheitswesen entspricht als auch eine intuitive Benutzeroberfläche für medizinisches Personal bietet.",
    image: "images/placeholder.jpg",
  },
  {
    id: "biometric-auth",
    title: "Biometrisches Authentifizierungssystem",
    description:
      "Implementierung eines mehrschichtigen Authentifizierungssystems mit Gesichtserkennung und Fingerabdruckscanner.",
    tags: ["Python", "OpenCV", "Biometrie", "Sicherheit"],
    category: "desktop",
    fullDescription:
      "Dieses Projekt entstand aus meinem Interesse an IT-Sicherheit und Biometrie. Ich entwickelte ein mehrschichtiges Authentifizierungssystem, das Gesichtserkennung und Fingerabdruckscans kombiniert, um einen hohen Sicherheitsstandard zu gewährleisten. Das System verwendet Algorithmen des maschinellen Lernens, um Gesichter zu erkennen und zu verifizieren, und integriert sich mit handelsüblichen Fingerabdruckscannern.",
    technologies: [
      "Python als Hauptprogrammiersprache",
      "OpenCV für die Bildverarbeitung und Gesichtserkennung",
      "TensorFlow für das Training der Gesichtserkennungsmodelle",
      "PyQt für die Benutzeroberfläche",
      "SQLite für die lokale Datenspeicherung",
      "Raspberry Pi für die Hardware-Integration",
    ],
    challenges:
      "Die Hauptherausforderung bestand darin, ein System zu entwickeln, das sowohl sicher als auch benutzerfreundlich ist, mit minimalen Falsch-Positiv- und Falsch-Negativ-Raten bei der biometrischen Erkennung.",
    image: "images/placeholder.jpg",
  },
  {
    id: "virtual-classroom",
    title: "Virtuelle Klassenzimmer-Plattform",
    description:
      "Entwicklung einer interaktiven Plattform für Online-Unterricht mit Echtzeit-Kollaboration und Fortschrittsverfolgung.",
    tags: ["React", "Node.js", "WebRTC", "MongoDB"],
    category: "web",
    fullDescription:
      "Inspiriert von meinen Erfahrungen im Fernunterricht entwickelte ich eine virtuelle Klassenzimmer-Plattform, die Echtzeit-Videokonferenzen, interaktive Whiteboards und Dokumentenfreigabe kombiniert. Die Plattform bietet Lehrern Tools zur Erstellung von Kursinhalten, zur Durchführung von Prüfungen und zur Verfolgung des Fortschritts der Schüler. Für Schüler bietet sie personalisierte Lernpfade und Kollaborationsmöglichkeiten.",
    technologies: [
      "React für das Frontend",
      "Node.js und Express für das Backend",
      "WebRTC für Echtzeit-Videokommunikation",
      "Socket.io für Echtzeit-Datenübertragung",
      "MongoDB für die Datenspeicherung",
      "AWS S3 für die Speicherung von Kursmaterialien",
    ],
    challenges:
      "Die größte Herausforderung war die Implementierung einer stabilen Echtzeit-Kommunikation mit niedriger Latenz, die auch bei schlechter Internetverbindung zuverlässig funktioniert.",
    image: "images/placeholder.jpg",
  },
  {
    id: "fitness-tracker",
    title: "Fitness-Tracking-App mit Gesundheitsanalyse",
    description:
      "Entwicklung einer mobilen App zur Verfolgung von Fitness-Aktivitäten und Gesundheitsmetriken mit personalisierten Empfehlungen.",
    tags: ["Flutter", "Firebase", "Machine Learning", "Health Tech"],
    category: "mobile",
    fullDescription:
      "Dieses Projekt verbindet mein Interesse an Fitness (Gym als Hobby) mit meinen technischen Fähigkeiten. Ich entwickelte eine umfassende Fitness-Tracking-App, die verschiedene Trainingsarten verfolgt, Ernährungspläne erstellt und Gesundheitsmetriken analysiert. Die App verwendet Algorithmen des maschinellen Lernens, um personalisierte Trainings- und Ernährungsempfehlungen basierend auf den Zielen und dem Fortschritt des Benutzers zu geben.",
    technologies: [
      "Flutter für die plattformübergreifende App-Entwicklung",
      "Firebase für Backend-Dienste und Authentifizierung",
      "TensorFlow Lite für On-Device Machine Learning",
      "HealthKit (iOS) und Google Fit (Android) Integration",
      "Cloud Functions für serverseitige Logik",
    ],
    challenges:
      "Die Hauptherausforderung bestand darin, genaue und personalisierte Empfehlungen zu generieren, die sowohl effektiv als auch sicher für verschiedene Benutzerprofile sind, von Anfängern bis zu fortgeschrittenen Sportlern.",
    image: "images/placeholder.jpg",
  },
  {
    id: "sap-integration",
    title: "SAP-Integrationsplattform für Unternehmensprozesse",
    description:
      "Entwicklung einer Integrationsplattform zur Verbindung von SAP ERP mit externen Systemen und Optimierung von Geschäftsprozessen.",
    tags: ["SAP ERP", "ABAP", "SAP HANA", "API Integration", "Prozessautomatisierung"],
    category: "enterprise",
    fullDescription:
      "Als Teil eines Unternehmensprojekts entwickelte ich eine Integrationsplattform, die SAP ERP mit verschiedenen externen Systemen verbindet. Die Lösung automatisiert den Datenaustausch zwischen SAP und anderen Unternehmensanwendungen, optimiert Geschäftsprozesse und reduziert manuelle Eingriffe. Durch die Integration von Echtzeit-Datenanalysen mit SAP HANA konnten Entscheidungsprozesse beschleunigt und die Effizienz gesteigert werden.",
    technologies: [
      "SAP ERP als zentrales System",
      "ABAP für kundenspezifische Entwicklungen",
      "SAP HANA für Echtzeit-Datenanalyse",
      "SAP Fiori für moderne Benutzeroberflächen",
      "REST APIs für die Integration externer Systeme",
      "SAP Process Integration für Workflow-Automatisierung",
    ],
    challenges:
      "Die größte Herausforderung bestand in der nahtlosen Integration verschiedener Systeme mit unterschiedlichen Datenformaten und Protokollen, während gleichzeitig die Sicherheit und Integrität der Unternehmensdaten gewährleistet werden musste.",
    image: "images/placeholder.jpg",
  },
]
