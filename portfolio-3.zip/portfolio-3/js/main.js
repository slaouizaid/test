document.addEventListener("DOMContentLoaded", () => {
  // Feather Icons initialisieren
  feather.replace()

  // Mobile Menu
  const mobileMenuBtn = document.querySelector(".mobile-menu-btn")
  const mobileMenuClose = document.querySelector(".mobile-menu-close")
  const mobileMenu = document.querySelector(".mobile-menu")
  const mobileNavLinks = document.querySelectorAll(".mobile-nav-link")

  mobileMenuBtn.addEventListener("click", () => {
    mobileMenu.classList.add("active")
  })

  mobileMenuClose.addEventListener("click", () => {
    mobileMenu.classList.remove("active")
  })

  mobileNavLinks.forEach((link) => {
    link.addEventListener("click", () => {
      mobileMenu.classList.remove("active")
    })
  })

  // Theme Toggle
  const themeToggle = document.getElementById("theme-toggle")
  const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)")

  // Check for saved theme preference or use the system preference
  const currentTheme = localStorage.getItem("theme")
  if (currentTheme === "dark" || (!currentTheme && prefersDarkScheme.matches)) {
    document.body.classList.add("dark-theme")
  }

  themeToggle.addEventListener("click", () => {
    if (document.body.classList.contains("dark-theme")) {
      document.body.classList.remove("dark-theme")
      localStorage.setItem("theme", "light")
    } else {
      document.body.classList.add("dark-theme")
      localStorage.setItem("theme", "dark")
    }
  })

  // Projekte laden
  const projectGrid = document.querySelector(".project-grid")
  const filterButtons = document.querySelectorAll(".filter-btn")
  const activeFilter = "all"

  // Dummy data for projects (replace with your actual data source)
  const projects = [
    {
      title: "Project 1",
      description: "A brief description of project 1.",
      fullDescription: "A more detailed description of project 1.",
      category: "web",
      tags: ["HTML", "CSS", "JavaScript"],
      technologies: ["React", "Node.js"],
      challenges: "Overcoming a specific technical hurdle.",
    },
    {
      title: "Project 2",
      description: "A brief description of project 2.",
      fullDescription: "A more detailed description of project 2.",
      category: "mobile",
      tags: ["React Native", "JavaScript"],
      technologies: ["React Native", "Firebase"],
      challenges: "Designing for different screen sizes.",
    },
    {
      title: "Project 3",
      description: "A brief description of project 3.",
      fullDescription: "A more detailed description of project 3.",
      category: "web",
      tags: ["HTML", "CSS", "JavaScript", "PHP"],
      technologies: ["Laravel", "MySQL"],
      challenges: "Optimizing database queries.",
    },
    {
      title: "Project 4",
      description: "A brief description of project 4.",
      fullDescription: "A more detailed description of project 4.",
      category: "design",
      tags: ["UI", "UX", "Figma"],
      technologies: ["Figma", "Adobe XD"],
      challenges: "Creating an intuitive user interface.",
    },
  ]

  // Projekte rendern
  function renderProjects(filter = "all") {
    projectGrid.innerHTML = ""

    const filteredProjects = filter === "all" ? projects : projects.filter((project) => project.category === filter)

    filteredProjects.forEach((project) => {
      const projectCard = document.createElement("div")
      projectCard.className = "project-card"
      projectCard.dataset.category = project.category

      projectCard.innerHTML = `
        <div class="project-content">
          <h3 class="project-title">${project.title}</h3>
          <p class="project-description">${project.description}</p>
          <div class="project-tags">
            ${project.tags.map((tag) => `<span class="badge">${tag}</span>`).join("")}
          </div>
        </div>
        <div class="project-overlay">
          <h3 class="project-title">${project.title}</h3>
          <p class="project-full-description">${project.fullDescription}</p>
          <div>
            <h4 class="project-tech-title">Technologien:</h4>
            <ul class="project-tech-list">
              ${project.technologies.map((tech) => `<li>${tech}</li>`).join("")}
            </ul>
          </div>
          <div class="project-challenge">
            <strong>Herausforderung:</strong>
            <p class="project-challenge-text">${project.challenges}</p>
          </div>
          <button class="btn btn-primary">Mehr Details</button>
        </div>
      `

      projectGrid.appendChild(projectCard)
    })
  }

  // Initial Projekte laden
  renderProjects(activeFilter)

  // Filter-Buttons
  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const filter = button.dataset.filter

      // Aktiven Button markieren
      filterButtons.forEach((btn) => btn.classList.remove("active"))
      button.classList.add("active")

      // Projekte filtern
      renderProjects(filter)
    })
  })

  // Kontaktformular
  const contactForm = document.getElementById("contact-form")
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault()

      // Hier würde normalerweise der Code zum Senden des Formulars stehen
      alert("Vielen Dank für Ihre Nachricht! Ich werde mich so schnell wie möglich bei Ihnen melden.")
      contactForm.reset()
    })
  }
})
