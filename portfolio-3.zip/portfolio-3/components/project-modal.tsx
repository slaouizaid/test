import Image from "next/image"
import { X } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

interface ProjectModalProps {
  open: boolean
  onClose: () => void
  project: {
    id: string
    title: string
    description: string
    fullDescription: string
    technologies: string[]
    challenges: string
    tags: string[]
    image: string
  }
}

export default function ProjectModal({ open, onClose, project }: ProjectModalProps) {
  if (!project) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{project.title}</DialogTitle>
          <DialogDescription>{project.description}</DialogDescription>
          <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
            <X className="h-4 w-4" />
            <span className="sr-only">Schließen</span>
          </DialogClose>
        </DialogHeader>
        <div className="relative h-[200px] w-full">
          <Image src={project.image || "/placeholder.svg"} alt={project.title} fill style={{ objectFit: "cover" }} />
        </div>
        <div className="mt-4">
          <p className="mb-4">{project.fullDescription}</p>
          <div className="mb-4">
            <h4 className="mb-2 font-medium">Verwendete Technologien:</h4>
            <ul className="list-inside list-disc space-y-1 text-sm text-muted-foreground">
              {project.technologies.map((tech, index) => (
                <li key={index}>{tech}</li>
              ))}
            </ul>
          </div>
          <div className="mb-4">
            <h4 className="mb-2 font-medium">Herausforderungen:</h4>
            <p className="text-sm text-muted-foreground">{project.challenges}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {project.tags.map((tag) => (
              <Badge key={tag} variant="secondary">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
